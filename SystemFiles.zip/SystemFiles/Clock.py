
import time
import SDL_DS3231

ds3231 = SDL_DS3231.SDL_DS3231(1, 0x68)

ds3231.write_now()

while True:
    print("Raspberry Pi =\t", time.strftime("%Y-%m-%d %H:%M:%S"))

    print("DS3231 =\t", ds3231.read_datetime())

    day_time = str(ds3231.read_datetime())
    print(day_time)

    f = open("timedate.txt", "w")
    f.write(day_time)
    f.close()

    time.sleep(1.0)
