
import spidev
from time import sleep

# Open SPI bus
spi = spidev.SpiDev()
spi.open(0, 0)

def analogInput(channel):
    spi.max_speed_hz = 1350000
    adc = spi.xfer2([1, (8 + channel) << 4, 0])
    data = ((adc[1] & 3) << 8) + adc[2]
    return data

def Volts(data):
    volts = (data * 3.3) / float(1023)
    volts = round(volts, 2)
    return volts

while True:
    temp_output = analogInput(0)
    temp_volts = Volts(temp_output)

    print("Volts: {}V".format(temp_volts))

    sleep(1)
