import RPi.GPIO as GPIO
from time import sleep

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)

Servopin=21

GPIO.setup(Servopin, GPIO.OUT)

p=GPIO.PWM(Servopin,50)
p.start(2.5)

try:
    while True:
        p.ChangeDutyCycle(2.5)
        sleep(1)

        p.ChangeDutyCycle(7.5)
        sleep(1)
        
        p.ChangeDutyCycle(12.5)
        sleep(1)
        
except KeyboardInterrupt:
    GPIO.cleanup()