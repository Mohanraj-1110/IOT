import time
import RPi.GPIO as GPIO

GPIO.setmode(GPIO.BCM)

Red=17
Blue=27
Green=22

GPIO.setwarnings(False)

GPIO.setup(Red,GPIO.OUT)
GPIO.setup(Blue,GPIO.OUT)
GPIO.setup(Green,GPIO.OUT)

try:
    while True:
        GPIO.output(Red,True)
        GPIO.output(Blue,False)
        GPIO.output(Green,False)
        time.sleep(1)
        GPIO.output(Red,False)
        GPIO.output(Blue,True)
        GPIO.output(Green,False)
        time.sleep(1)
        GPIO.output(Red,False)
        GPIO.output(Blue,False)
        GPIO.output(Green,True)
        time.sleep(1)
except KeyboardInterrupt:
    GPIO.output(Red,False)
    GPIO.output(Blue,False)
    GPIO.output(Green,False)
    GPIO.cleanup()
        