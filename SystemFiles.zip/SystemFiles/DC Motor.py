import RPi.GPIO as GPIO
from time import sleep

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)

in_1=13
in_2=19

GPIO.setup(in_1,GPIO.OUT)
GPIO.setup(in_2,GPIO.OUT)

try:
    while True:
        GPIO.output(in_1,True)
        GPIO.output(in_2,False)
        sleep(5)
        GPIO.output(in_1,False)
        GPIO.output(in_2,True)
        sleep(5)
        
except KeyboardInterrupt:
    GPIO.output(in_1,False)
    GPIO.output(in_2,False)
    GPIO.cleanup()
    