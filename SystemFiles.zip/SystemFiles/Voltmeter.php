<html>
    <head>
        <title> Online Voltmeter</title>
    </head>
    <body>
        <h1>Online Voltmeter</h1>
        <p>Voltage Reading:</p>
        <?php
        $myfile=fopen("/var/www/html/voltdata.txt","r")or die("unable to open file!");
        echo fread($myfile,filesize("/var/www/html/voltdata.txt"));
        fclose($myfile);
        ?>
    </body>
</html>