<html>
    <head>
        <title>IOT RealTimeClock</title>
    </head>
<?php
header("Refresh: 1");
$myfile=fopen("/var/www/html/timedata.txt","r") or die("Unable to open");
echo fread($myfile,filesize('/var/www/html/timedata.txt'));
fclose($myfile);
?>
</html>