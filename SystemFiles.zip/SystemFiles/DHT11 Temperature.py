from liquidcrystal_i2c import LCD
import dht11
import time
import RPi.GPIO as GPIO

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)

instance=dht11.DHT11(pin=14)
lcd=LCD(bus=1,addr=0x3f,cols=16,rows=2)

while True:
    result=instance.read()
    if result.is_valid():
        t=str(result.temperature)
        h=str(result.humidity)
        print("Temperature: %{} C",format(t))
        print("Humidity:{}%",format(h))
        lcd.setCursor(0,0)
        lcd.print("TEMP:")
        lcd.setCursor(6,0)
        lcd.print(t+"c")
        lcd.setCursor(0,1)
        lcd.print("HUMI:")
        lcd.setCursor(6,1)
        lcd.print(h+"%")
        time.sleep(1)