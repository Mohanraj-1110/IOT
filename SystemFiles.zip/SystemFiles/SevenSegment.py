import RPi.GPIO as GPIO
import time
import os,sys
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)

GPIO.setup(5,GPIO.OUT)#a
GPIO.setup(6,GPIO.OUT)#b
GPIO.setup(13,GPIO.OUT)#c
GPIO.setup(19,GPIO.OUT)#d
GPIO.setup(26,GPIO.OUT)#e
GPIO.setup(21,GPIO.OUT)#f
GPIO.setup(20,GPIO.OUT)#g

digitclr=[0,0,0,0,0,0,0]
digit0=[1,1,1,1,1,1,0]
digit1=[0,1,1,0,0,0,0]
digit2=[1,1,0,1,1,0,1]
digit3=[1,1,1,1,0,0,1]
digit4=[0,1,1,0,0,1,1]
digit5=[1,0,1,1,0,1,1]
digit6=[1,0,1,1,1,1,1]
digit7=[1,1,1,0,0,0,0]
digit8=[1,1,1,1,1,1,1]
digit9=[1,1,1,0,0,1,1]
digitA=[1,1,1,0,1,1,1]
digitB=[1,1,1,1,1,1,1]
digitC=[1,0,0,1,1,1,0]
digitD=[0,1,1,1,1,0,1]
digitE=[1,0,0,1,1,1,1]
digitF=[1,0,0,0,1,1,1]
digitg=[1,1,1,1,0,1,1]



gpin=[5,6,13,19,26,21,20]
def digdisp(digit):
    for x in range(0,7):
        GPIO.output(gpin[x],digitclr[x])
    for x in range(0,7):
        GPIO.output(gpin[x],digit[x])
while True:
    digdisp(digit9)
    time.sleep(1)
    digdisp(digit8)
    time.sleep(1)
    digdisp(digit7)
    time.sleep(1)
    digdisp(digit6)
    time.sleep(1)
    digdisp(digit5)
    time.sleep(1)
    digdisp(digit4)
    time.sleep(1)
    digdisp(digit3)
    time.sleep(1)
    digdisp(digit2)
    time.sleep(1)
    digdisp(digit1)
    time.sleep(1)
    digdisp(digit0)
    time.sleep(1)
    digdisp(digitA)
    time.sleep(1)
    digdisp(digitB)
    time.sleep(1)
    digdisp(digitC)
    time.sleep(1)
    digdisp(digitD)
    time.sleep(1)
    digdisp(digitE)
    time.sleep(1)
    digdisp(digitF)
    time.sleep(1)
    digdisp(digitg)
    time.sleep(1)
    GPIO.cleanup()