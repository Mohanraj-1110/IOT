import BlynkLib
import RPi.GPIO as GPIO
from BlynkTimer import BlynkTimer
import dht11
import time

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)

LED_PIN = 18
DHT_PIN = 14

GPIO.setup(LED_PIN, GPIO.OUT)
GPIO.output(LED_PIN, GPIO.LOW)

instance = dht11.DHT11(pin=DHT_PIN)

BLYNK_AUTH_TOKEN = ""


blynk = BlynkLib.Blynk(
    BLYNK_AUTH_TOKEN,
    server="blynk.cloud",
    port=80
)


timer = BlynkTimer()


@blynk.on("V0")
def v0_write_handler(value):
    try:
        if int(value[0]) != 0:
            GPIO.output(LED_PIN, GPIO.HIGH)
            print("LED ON")
        else:
            GPIO.output(LED_PIN, GPIO.LOW)
            print("LED OFF")

    except Exception as e:
        print("LED error:", e)



def myData():

    try:
        result = instance.read()

        if result.is_valid():

            temperature = int(result.temperature)
            humidity = int(result.humidity)

            print("-------------------------")
            print("Temperature: {} C".format(temperature))
            print("Humidity: {} %".format(humidity))

            
            blynk.virtual_write(1, temperature)

            
            blynk.virtual_write(2, humidity)

            print("Values sent to Blynk")

        else:
            print("DHT11 reading failed")

    except Exception as e:
        print("Sensor error:", e)



timer.set_interval(2, myData)

@blynk.on("connected")
def blynk_connected():
    print("Raspberry Pi connected to Blynk Cloud")

    blynk.sync_virtual(0)

try:

    print("Starting Raspberry Pi Blynk program...")

    while True:
        blynk.run()
        timer.run()
        time.sleep(0.01)

except KeyboardInterrupt:

    print("\nProgram stopped")

finally:

    GPIO.output(LED_PIN, GPIO.LOW)
    GPIO.cleanup()
    print("GPIO cleaned up")